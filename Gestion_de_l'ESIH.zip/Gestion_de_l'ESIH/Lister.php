<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Enregistrement </title>
<link rel="stylesheet" href="bootstrap.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/jquery.bxslider.css">
  <link rel="stylesheet" type="text/css" href="css/normalize.css" />
  <link rel="stylesheet" type="text/css" href="css/demo.css" />
  <link rel="stylesheet" type="text/css" href="css/set1.css" />
  <link href="css/overwrite.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  </head>
<body>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
      <!-- Brand and toggle get grouped for better mobile display -->

      <div class="navbar-collapse collapse">
      <div style="border:none;width:auto;height:40px;float:right;margin-top:10;margin-left:5px;">
        <form action="" method="GET">
        <button type="submit" class="btn btn-primary" name="Recherche">Recherche</button>
      </div>
      <div style="border:none;width:auto;height:40px;float:right;margin-top:11px;">
      <input type="text" name="Position" class="form-control" id="inputPassword2" placeholder="Recherche"style="width:140px;text-align:center;color:cadetblue;FONT-WEIGHT:BOLDER;">
      </div>
      </form>
        <div class="menu">
          <ul class="nav nav-tabs" role="tablist">
          <a class="navbar-brand" href="index.html"><span>ESIH</span></a>
            <li role="presentation" ><a href="form.php">Enregistrements</a></li>
            <li role="presentation" class="active"><a href="Lister.php">Lister</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
<br><br><br>
  <div style="margin:auto;padding:auto;width:auto;height:auto;border:0.5px dotted cadetblue;margin-top:10px;color:cadetblue;box-shadow:2px 2px 10px cadetblue;">
            <div class="card">
            <h4 class="card-header" style="text-align:center;color:cadetblue;">Lister du personnel</h4>
            <div class="card-body">
            <table class="table">
                <thead class="thead-light" style="text-align:center;color:cadetblue;">
                    <tr>
                    <th scope="col">Code</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Prénom</th>
                    <th scope="col">Sexe</th>
                    <th scope="col">Nationalité</th>
                    <th scope="col">Date_Naissance</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Type_Personne</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    if(isset($_SESSION['Personnel'])){
                        if(!empty($_SESSION['Personnel'])){
                        if(isset($_GET['Recherche'])){
                        $Position = (int)$_GET['Position'];
                        echo("<tr>");
                        echo('<td>'.$_SESSION['Personnel'][$Position]['code'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['nom'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['prenom'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Sexe'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Date_Naissance'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Nationalité'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Téléphone'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Email'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Type'].'</td>');
                        echo("</tr>");
                        
                    //getCode($recherche);
                        }
                    }
                    }
                        
                ?>
                </tbody>
                </table>
                    <br><br>
                <table class="table">
                <thead class="thead-light" style="text-align:center;color:cadetblue;">
                    <tr>
                    <th scope="col">Code</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Prénom</th>
                    <th scope="col">Sexe</th>
                    <th scope="col">Nationalité</th>
                    <th scope="col">Date_Naissance</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Type_Personne</th>
                    </tr>
                </thead>
                <tbody>
                        <?php
                          if(isset($_SESSION['Personnel'])){
                              if(!empty($_SESSION['Personnel'])){
                          foreach($_SESSION['Personnel'] as $t){
                                  echo("
                                      <tr>
                                          <td>$t[code]</td>
                                          <td>$t[nom]</td>
                                          <td>$t[prenom]</td>
                                          <td>$t[Sexe]</td>
                                          <td>$t[Date_Naissance]</td>
                                          <td>$t[Nationalité]</td>
                                          <td>$t[Téléphone]</td>
                                          <td>$t[Email]</td>
                                          <td>$t[Type]</td>
                                      </tr>
                                  
                                  ");
                                  }
                              }
                          }
                      ?>
                </tbody>
                </table>
            </div>
            </div>

  </div>
</body>
</html>