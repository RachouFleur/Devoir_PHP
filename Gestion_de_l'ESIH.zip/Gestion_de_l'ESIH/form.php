<?php
    session_start();
?>


        <?php
            require_once 'ClassPersonnel.php';
            
            if(isset($_POST["Enregister"])){
                $code = $_POST['code'];
                $nom = $_POST['nom'];
                $prenom = $_POST['prenom'];
                $Sexe=$_POST['Sexe'];
                $Date_Naissance=$_POST['Date_Naissance'];
                $Nationalité=$_POST['Nationalité'];
                $Téléphone=$_POST['Téléphone'];
                $Email=$_POST['Email'];
                $Type= $_POST['Type'];
					$et = new Personnel($code,$nom,$prenom,$Sexe,$Date_Naissance,$Nationalité,$Téléphone,$Email,$Type);
					$t_et = [
						'code'=>$et->getCode(),
						'nom'=>$et->getNom(),
						'prenom'=>$et->getPrenom(),
						'Sexe'=>$et->getSexe(),
						'Date_Naissance'=>$et->getDate_Naissance(),
						'Nationalité'=>$et->getNationalité(),
						'Téléphone'=>$et->getTéléphone(),
						'Email'=>$et->getEmail(),
						'Type'=>$et->getType()
						];
                            
					$_SESSION['Personnel'][]=$t_et;
                
                                   
        }


    ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Enregistrement </title>
<link rel="stylesheet" href="bootstrap.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/jquery.bxslider.css">
  <link rel="stylesheet" type="text/css" href="css/normalize.css" />
  <link rel="stylesheet" type="text/css" href="css/demo.css" />
  <link rel="stylesheet" type="text/css" href="css/set1.css" />
  <link href="css/overwrite.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
    
  <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
      
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
        
      </div>
      <div class="navbar-collapse collapse">
        <div class="menu">
          <ul class="nav nav-tabs" role="tablist">
          <a class="navbar-brand" href="index.html"><span>ESIH</span></a>
            <li role="presentation" class="active"><a href="form.php">Enregistrements</a></li>
            <li role="presentation"><a href="Lister.php">Lister</a></li>
            <li role="presentation"><a href="Lister.php">Recherche</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
  
  <!-- formulaire -->

<br><br><br>
  <div class="card">
    <div class="card-header">
      Formulaire
    </div>
    <div class="card-body">
    <form action="form.php" method="POST">
      <div class="row">
        <div class="col-md-6 mb-3">
        <label for="">Code</label>
          <input type="text" name="code" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="">Nom</label>
          <input type="text" name="nom" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="">Prénom</label>
          <input type="text" name="prenom" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="">Sexe</label>
          <input type="text" name="Sexe" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="">Date de Naissance</label>
          <input type="date" name="Date_Naissance" class="form-control" id="validationCustom01" placeholder="" value="" required>
          
        </div>
        <div class="col-md-6 mb-3">
        <label for="">Nationalité</label>
          <input type="text" name="Nationalité" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="validationServer02">Téléphone</label>
          <input type="text" name="Téléphone" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="validationServer02">Email</label>
          <input type="text" name="Email" class="form-control" id="validationCustom01" placeholder="" value="" required>
          <label for="validationServer02">Type_Personne</label>
          <select class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect"  name="Type">
                            <option selected>Choose...</option>
                            <option value="Etudiants">Etudiants</option>
                            <option value="Professeurs">Professeurs</option>
                            <option value="Personnelles Administratives">Personnelles Administratives</option>
                          
                        </select>
          <br>
          <button class="btn btn-primary" type="submit" name="Enregister">Valider</button>
          <a href="Lister.php">Lister </a>
        </div>
      </div>
      </form>
  </body>
</html>
